package com.example;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class Main 
{

    public static void main( String[] args ) throws  IOException
    {
            //Deserializzazione
            File file = new File("src/main/resources/classe.xml");
            XmlMapper xmlMapper = new XmlMapper();
            Root value = xmlMapper.readValue(file, Root.class);
            System.out.println("La classe " +value.getClasse() +" " +value.getSpecializzazione() +" si trova nell'aula " +value.getAula().getNome() +" ed è composta dai studenti:");
            for(int i=0; i<value.getStudenti().size(); i++){
                System.out.println("- " +value.getStudenti().get(i).getCognome());
            }

            //Serializzazione
            xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);
            xmlMapper.writeValue(new File("src/main/resources/classeSerializzata.xml"), value);
            File file2 = new File("classeSerializzata.xml");    
    }
    
}
