package com.example;


public class element {
    private int annoDiNascita;
    private String cognome;
    private String nome;

    public int getAnnoDiNascita() {
        return annoDiNascita;
    }
    public void setAnnoDiNascita(int annoDiNascita) {
        this.annoDiNascita = annoDiNascita;
    }
    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
}
